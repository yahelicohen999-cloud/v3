module.exports = { reactStrictMode: true, experimental: { serverActions: true } };
